# SparkBank
<h3>The Sparks Foundation Internship Project : Basic Banking System</h3>
A Dynamic Website is used to transfer money between 10 users.<br>
Stack used -
<h4>Front-end : HTML, CSS, Bootstrap &amp; Javascript</h4>
<h4>Back-end : PHP</h4>
<h4>Database : MySQL</h4>
The Database contains two Tables- Users Table &amp; Transaction Table <br>
The User table have basic fields such as name, email &amp; current balance. <br>
The Transaction table records all transfers happened along with their time. <br>
The Flow of the Website: <br>
Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.